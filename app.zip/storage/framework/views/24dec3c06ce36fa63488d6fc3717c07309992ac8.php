
<?php $__env->startSection('content'); ?>



<?php echo $__env->make('components.additional.errorMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>







<div class="justify-content-md-center row">
    <div class="col-xl-12 col-md-12 pl-4">
      <br />
      <div class="container-fluid">
       
        <div class="row">
          <div class="col-6">
            <h5 class="text text-secondary">Open Orders</h5>
          </div>
          
        </div>
      </div>

      <div class="container-fluid">
        <div class="justify-content-center row">
          <h5 class="text-success text-center mb-3">
            <br />
            Open to Bid
          </h5>
          <div class="row" style="width: 100%">
            <div class="text-center col-2" style="font-size: 10px">
              <b>ID</b>
            </div>
            <div class="text-center col" style="font-size: 10px">
              <b>Name</b>
            </div>


            <div class="text-center col-1" style="font-size: 10px">
              <b>Deadline</b>
            </div>
          


             <div class="text-center col" style="font-size: 10px">
              <b>Action</b>
            </div>

          
          </div>

          <?php $__empty_1 = true; $__currentLoopData = $ordersOpen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $openOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              
          
              
          
          <div
            class="shadow card border-primary button"
            style="padding: 5px; width: 100%; cursor: pointer"
          >
            <div class="align-items-center row" style="font-size: 11px" >
              <div class="text-center col-2"> <?php echo e($openOrder->code); ?></div>
              <div class="text-center col"><?php echo e($openOrder->supply_point_name); ?></div>

              <?php
              $requestTimeDeadline = $openOrder->deadline_offer_recive;
                $formattedTimeDeadline = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $requestTimeDeadline)->format('F j, Y, g:i a');
              ?>
              <div class="text-center col-1"><?php echo e($formattedTimeDeadline); ?> </div>

  

              <div class="text-center col" >
                <div class="btn-group">
                  <button type="button" class="btn btn-success btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_view<?php echo e($openOrder->id); ?>">view</button>


                  <?php

                  $currentBid = null;

                      foreach ($sellerHasBids as $key => $sellerBid) {
                          if ($sellerBid->order_id == $openOrder->id) {
                           $currentBid = $sellerBid;
                          }
                      }
                  ?>




                  


                        <?php if($currentBid != null): ?>

                        <button type="button" class="btn btn-primary btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_edit<?php echo e($openOrder->id); ?>">View or Modify Offer</button>

                        <?php else: ?>

                        <button type="button" class="btn btn-primary btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_edit<?php echo e($openOrder->id); ?>">Apply</button>

                      
                        <?php endif; ?>




                </div>
              </div>


              

                        <div class="modal fade" id="modal_edit<?php echo e($openOrder->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">


                                <h5 class="modal-title" id="exampleModalLabel">Apply For: <?php echo e($openOrder->supply_point_name); ?>  </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>

                              

                              <?php echo $__env->make('components.seller.applyModal', [
                                'openOrder' => $openOrder,
                                'currentBid' => $currentBid
                              ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              
                              
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>


              




             


              <div class="modal fade" id="modal_view<?php echo e($openOrder->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel"><?php echo e($openOrder->supply_point_name); ?> </h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    
                    <?php echo $__env->make('components.seller.viewModal', [
                      'openOrder' => $openOrder,
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>



              
            </div>
          </div>


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>



          <div
          class="shadow card border-primary"
          style="padding: 5px; width: 100%; cursor: pointer"
        >
          <div class="align-items-center row text-center" style="font-size: 11px">
              <div class="col">
                No Data Available
              </div>
          </div>
        </div>


          <?php endif; ?>



        </div>


        
        
      </div>



      


      <div class="justify-content-center row">
        <h5 class="text-success text-center mb-3">
          <br />
          In Analysis
        </h5>

        <div class="row" style="width: 100%">
          <div class="text-center col-2" style="font-size: 10px">
            <b>ID</b>
          </div>
          <div class="text-center col" style="font-size: 10px">
            <b>Name</b>
          </div>
          <div class="text-center col-1" style="font-size: 10px">
            <b>Deadline</b>
          </div>
         
        
          <div class="text-center col" style="font-size: 10px">
            <b>Action</b>
          </div>


        </div>




        <?php $__empty_1 = true; $__currentLoopData = $ordersUnderAnalysis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysisOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
        
            
        
        <div
          class="shadow card border-primary"
          style="padding: 5px; width: 100%; cursor: pointer"
        >
          <div class="align-items-center row" style="font-size: 11px">
            <div class="text-center col-2"> <?php echo e($analysisOrder->code); ?></div>
            <div class="text-center col"><?php echo e($analysisOrder->supply_point_name); ?></div>

            <?php
            $requestTimeAnaylsis = $analysisOrder->deadline_offer_recive;
              $formattedTimeAnalysis = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $requestTimeAnaylsis)->format('F j, Y, g:i a');
            ?>
            <div class="text-center col-1"><?php echo e($formattedTimeAnalysis); ?> </div>


              <div class="text-center col" >
                <div class="btn-group">
               
                  <button type="button" class="btn btn-success btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_view<?php echo e($analysisOrder->id); ?>">view</button>
                 
                </div>







                

                <div class="modal fade" id="modal_view<?php echo e($analysisOrder->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e($analysisOrder->supply_point_name); ?> </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>

                      <?php echo $__env->make('components.seller.viewModal', [
                        'openOrder' => $analysisOrder,
                      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>


                


           
</div>
            
          </div>
        </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>



        <div
        class="shadow card border-primary"
        style="padding: 5px; width: 100%; cursor: pointer"
      >
        <div class="align-items-center row text-center" style="font-size: 11px">
            <div class="col">
              No Data Available
            </div>
        </div>
      </div>


        <?php endif; ?>



      </div>
      






      

      <div class="justify-content-center row">
        <h5 class="text-success text-center mb-3">
          <br />
          Awarded
        </h5>
        <div class="row" style="width: 100%">
          <div class="text-center col-2" style="font-size: 10px">
            <b>ID</b>
          </div>
          <div class="text-center col" style="font-size: 10px">
            <b>Name</b>
          </div>
          <div class="text-center col-1" style="font-size: 10px">
            <b>Deadline</b>
          </div>
         
        
          <div class="text-center col" style="font-size: 10px">
            <b>Action</b>
          </div>


        </div>

        <?php $__empty_1 = true; $__currentLoopData = $ordersAwarded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $awardedOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
        
            
        
        <div
          class="shadow card border-primary"
          style="padding: 5px; width: 100%; cursor: pointer"
        >
          <div class="align-items-center row" style="font-size: 11px">
            <div class="text-center col-2"> <?php echo e($awardedOrder->code); ?></div>
            <div class="text-center col"><?php echo e($awardedOrder->supply_point_name); ?></div>

            <?php
            $requestTimeAwarded = $awardedOrder->deadline_offer_recive;
              $formattedTimeAwarded = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $requestTimeAwarded)->format('F j, Y, g:i a');
            ?>
            <div class="text-center col-1"><?php echo e($formattedTimeAwarded); ?> </div>



            
            <div class="text-center col" >
              <div class="btn-group">
             
                <button type="button" class="btn btn-success btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_view<?php echo e($awardedOrder->id); ?>">view</button>
             
              </div>


              

              <div class="modal fade" id="modal_view<?php echo e($awardedOrder->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel"><?php echo e($awardedOrder->supply_point_name); ?> </h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    
            <?php echo $__env->make('components.seller.viewModal', [
              'openOrder' => $awardedOrder,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>



         
</div>
            
          </div>
        </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>



        <div
        class="shadow card border-primary"
        style="padding: 5px; width: 100%; cursor: pointer"
      >
        <div class="align-items-center row text-center" style="font-size: 11px">
            <div class="col">
              No Data Available
            </div>
        </div>
      </div>


        <?php endif; ?>



      </div>


      




      <div class="justify-content-center row">
        <h5 class="text-danger text-center mb-3">
          <br />
          Deserts
        </h5>
        <div class="row" style="width: 100%">
          <div class="text-center col-2" style="font-size: 10px">
            <b>ID</b>
          </div>
          <div class="text-center col" style="font-size: 10px">
            <b>Name</b>
          </div>
          <div class="text-center col-1" style="font-size: 10px">
            <b>Deadline</b>
          </div>
         
        
          <div class="text-center col" style="font-size: 10px">
            <b>Action</b>
          </div>


        </div>

        <?php $__empty_1 = true; $__currentLoopData = $ordersDesert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desertOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
        
            
        
        <div
          class="shadow card border-primary"
          style="padding: 5px; width: 100%; cursor: pointer"
        >
          <div class="align-items-center row" style="font-size: 11px">
            <div class="text-center col-2"> <?php echo e($desertOrder->code); ?></div>
            <div class="text-center col"><?php echo e($desertOrder->supply_point_name); ?></div>

            <?php
            $requestTimeDesert = $desertOrder->deadline_offer_recive;
              $formattedTimeDesert = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $requestTimeDesert)->format('F j, Y, g:i a');
            ?>
            <div class="text-center col-1"><?php echo e($formattedTimeDesert); ?> </div>


            <div class="text-center col" >
              <div class="btn-group">
             
                <button type="button" class="btn btn-success btn-sm m-1" data-bs-toggle="modal" data-bs-target="#modal_view<?php echo e($desertOrder->id); ?>">view</button>
               
              </div>




              

              <div class="modal fade" id="modal_view<?php echo e($desertOrder->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel"><?php echo e($desertOrder->supply_point_name); ?> </h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    
            <?php echo $__env->make('components.seller.viewModal', [
              'openOrder' => $openOrder,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>


              

         
</div>





            
          </div>
        </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>



        <div
        class="shadow card border-primary"
        style="padding: 5px; width: 100%; cursor: pointer"
      >
        <div class="align-items-center row text-center" style="font-size: 11px">
            <div class="col">
              No Data Available
            </div>
        </div>
      </div>


        <?php endif; ?>



      </div>







    </div>

    
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/seller/index.blade.php ENDPATH**/ ?>