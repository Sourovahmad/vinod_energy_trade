  <!-- Footer -->
  <footer class="sticky-footer bg-light">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; <?php echo e(config('app.name', 'Laravel')); ?> - <?php echo e(now()->format("Y")); ?></span>
      </div>
    </div>
   </footer>
  <!-- End of Footer --><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/components/admin/footer.blade.php ENDPATH**/ ?>