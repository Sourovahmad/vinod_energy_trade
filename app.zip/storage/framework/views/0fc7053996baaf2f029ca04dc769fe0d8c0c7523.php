

<?php $__env->startSection('content'); ?>

<div class="container mt-4" style="border: 1px solid #3e3e3d">
  





<?php echo $__env->make('components.additional.errorMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



   
    <div class="header border-bottom mt-2">
      <p>   Add the Natural Gas bid </p>
       
      </div>



<form action="<?php echo e(route('bidAdd')); ?>" method="post" enctype="multipart/form-data" id="natural_bid_add_form">  

    <?php echo csrf_field(); ?>

      <div class="d-flex flex-column">
        <div>


          
            <div class="form-group mt-2">
                <div class="row">
                  <div class="col-4">
                    <p>Supply Point Name</p>
                  </div>
                  <div class="col-3">
                    <input type="text" class="select py-2" name="supply_point_name" required  id="input_supply_point_name"/>
                  </div>
                </div>
              </div>



              <div class="form-group mt-2">
                <div class="row">
                  <div class="col-4">
                    <p>Geographic Location (Province location)</p>
                  </div>
                  <div class="col-3">
                    <input type="text" class="select py-2" name="location_of_supply_point" id="input_location" required />
                  </div>
                </div>
              </div>


              <input type="text" name="purchase_request_for" value="NATURAL GAS" hidden required>




          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Deadline for receipt of Offers:</p>
              </div>
              <div class="col-3">
                <input type="datetime-local" class="select" name="deadline_offer_recive" required />
              </div>
            </div>
          </div>



          <div class="form-group">
            <div class="row">
              <div class="col-4">
                <p>Date of publication of the Purchase Order:</p>
              </div>
              <div class="col-3">
                <input type="datetime-local" class="select" name="publication_date" required />
              </div>
            </div>
          </div>




          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Natural Gas Distributor POINT OF CONSUMPTION 1:</p>
              </div>
              <div class="col-3">
                <select class="select" name="natural_gas_point_of_distribution_consumtion_1">
                  <option value="Metrogas Metropolitan Subzone">
                    Metrogas Metropolitan Subzone
                  </option>
                  <option value="Naturgy BAN SA Subzone Buenos Aires North">
                    Naturgy BAN SA Subzone Buenos Aires North
                  </option>
                  <option value="Camuzzi Gas Pampeana Subzone Buenos Aires">
                    Camuzzi Gas Pampeana Subzone Buenos Aires
                  </option>
                  <option value="Camuzzi Gas Bahía Blanca Subzone">
                    Camuzzi Gas Bahía Blanca Subzone
                  </option>
                  <option value="Camuzzi Gas La Pampa North Subzone">
                    Camuzzi Gas La Pampa North Subzone
                  </option>
                  <option value="Camuzzi Gas La Pampa South Subzone">
                    Camuzzi Gas La Pampa South Subzone
                  </option>
                  <option value="Camuzzi Gas del Sur Subzone Neuquén">
                    Camuzzi Gas del Sur Subzone Neuquén
                  </option>
                  <option value="Camuzzi Gas del Sur Cordillerano Subzone">
                    Camuzzi Gas del Sur Cordillerano Subzone
                  </option>
                  <option
                    value="Camuzzi Gas del Sur Subzone Buenos Aires South"
                  >
                    Camuzzi Gas del Sur Subzone Buenos Aires South
                  </option>
                  <option value="Camuzzi Gas del Sur Subzone Chubut Sur">
                    Camuzzi Gas del Sur Subzone Chubut Sur
                  </option>
                  <option value="Camuzzi Gas del Sur Subzone Santa Cruz Sur">
                    Camuzzi Gas del Sur Subzone Santa Cruz Sur
                  </option>
                  <option
                    value="Camuzzi Gas del Sur Subzone Tierra del Fuego"
                  >
                    Camuzzi Gas del Sur Subzone Tierra del Fuego
                  </option>
                  <option value="Cuyana Gas Distributor Cuyo Subzone">
                    Cuyana Gas Distributor Cuyo Subzone
                  </option>
                  <option value="Cuyana Gas Distributor Malargüe Subzone">
                    Cuyana Gas Distributor Malargüe Subzone
                  </option>
                  <option
                    value="Gas Distributor of the Center Subzone Center"
                  >
                    Gas Distributor of the Center Subzone Center
                  </option>
                  <option value="Litoral Gas Subzone Litoral">
                    Litoral Gas Subzone Litoral
                  </option>
                  <option value="Gasnor Subzone Salta">
                    Gasnor Subzone Salta
                  </option>
                  <option value="Gasnor Subzone Tucumán">
                    Gasnor Subzone Tucumán
                  </option>
                  <option value="Gasnea Entre Ríos Subzone">
                    Gasnea Entre Ríos Subzone
                  </option>
                  <option value="Gasnea Subzone Paraná">
                    Gasnea Subzone Paraná
                  </option>
                  <option value="Gasnea Subzone Corrientes">
                    Gasnea Subzone Corrientes
                  </option>
                  <option value="Gasnea Chaco Subzone">
                    Gasnea Chaco Subzone
                  </option>
                  <option value="Gasnea Subzone Formosa">
                    Gasnea Subzone Formosa
                  </option>
                  <option value="Gasnea Subzone Misiones">
                    Gasnea Subzone Misiones
                  </option>
                </select>
              </div>
            </div>
          </div>


          <div class="form-group mt-3 mb-4">
            <div class="row align-items-center">
              <div class="col-4">
                <p>Natural Gas Tariff POINT OF CONSUMPTION 1</p>
              </div>
              <div class="col-3">
                <select class="select" name="natural_gas_tarrif_point_of_consumption_1">
                  <option value="SGP3">SGP3</option>
                  <option value="SGG">SGG</option>
                  <option value="CNG">CNG</option>
                  <option value="GU">GU</option>
                </select>
              </div>
              <div class="col-4">
                <div class="row align-items-center">
                  <div class="col-6">
                    <p>RESERVE (dam3/day) </p>
                  </div>
                  <div class="col-6">
                    <input type="text" class="select py-2" name="reserve" required />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          






          <span class="border-bottom  mb-4 mt-4 p-2"> Consumption Curve POINT OF CONSUMPTION 1 </span>
          

          
          <div class="form-group mt-3">
            <div class="row">
              <div class="col-4">
                <p>January </p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_january" required />
              </div>
            </div>
          </div>



          
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>February </p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_february" required />
              </div>
            </div>
          </div>


          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>March</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_march"  required/>
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>April</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_april" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>May</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_may" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>June</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_june" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>July</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_july" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>August</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_august" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>September</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_september" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>October</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_october" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>November</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_november" required />
              </div>
            </div>
          </div>
          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>December</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="expected_december" required />
            </div>
        </div>
      </div>




        <div class="mt-4 mb-4">
          <span class="border-bottom ">Contract Conditions:</span>
        </div>
  
          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Contract Term (months)</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="contact_term_months" required />
              </div>
            </div>
          </div>


          
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Start of Supply:</p>
              </div>
              <div class="col-3">
                <input type="date" class="select" name="start_of_supply" required />
              </div>
            </div>
          </div>



    


 
          <div class="mt-4 mb-4">
            <span class="border-bottom ">Cuenca Winter Mix:</span>
          </div>


          <div class="form-group mt-3">
            <div class="row">
              <div class="col-4">
                <p>NQN:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" max="100" name="winter_mqn" id="summer_1" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>PTO:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="winter_pto" id="summer_2" required  />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>SCR:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" max="100" name="winter_scr" id="summer_3" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>CHU:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2"  max="100" name="winter_chu" id="summer_4" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>NOA:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2"  max="100" name="winter_noa" id="summer_5" required />
              </div>
            </div>
          </div>

          
          <div class="mt-4 mb-4">
            <span class="border-bottom ">Cuencas Summer Mix</span>
          </div>



          <div class="form-group mt-3">
            <div class="row">
              <div class="col-4">
                <p>NQN:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2"   max="100" name="summer_mqn" id="winter_1" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>PTO:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2" name="summer_pto" id="winter_2" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>SCR:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2"  max="100" name="summer_scr" id="winter_3" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>CHU:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2"  max="100" name="summer_chu" id="winter_4" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>NOA:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select py-2"  max="100" name="summer_noa" id="winter_5" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Type of Supply:</p>
              </div>
              <div class="col-3 d-flex">
                <div class="pr-4">
                  <input
                    type="radio"
                    value="Firm"
                    id="Firm"
                    name="type_of_supply"
                    required
                  />
                  <label for="Firm">Firm</label>
                </div>
                <div>
                  <input
                    type="radio"
                    value="Spot"
                    id="Spot"
                    name="type_of_supply"
                    required
                  />
                  <label for="Spot">Spot</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Exclusivity:</p>
              </div>
              <div class="col-3">
                <select class="select" name="exclusivity" required>
                  <option value="YES">YES</option>
                  <option value="NO">NO</option>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Partial Award:</p>
              </div>
              <div class="col-3">
                <select class="select" name="partial_award" required>
                  <option value="YES">YES</option>
                  <option value="NO">NO</option>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Price:</p>
              </div>
              <div class="col-3">
                <select class="select" name="price" required>
                  <option value="Flat">Flat</option>
                  <option value="Seasonal">Seasonal</option>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Price Renegotiation Clause:</p>
              </div>
              <div class="col-3">
                <select class="select" name="price_renegotiation" required>
                  <option value="YES">YES</option>
                  <option value="NO">NO</option>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Take or Pay optional to the Seller:</p>
              </div>
              <div class="col-3">
                <select class="select" name="take_or_pay_optional_to_seller" required>
                  <option value="YES">YES</option>
                  <option value="NO">NO</option>
                </select>
              </div>
            </div>
          </div>
          <span class="border-bottom"
            >In case the previous answer is NO:
          </span>
          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Take or Pay (0 to 100%):</p>
              </div>
              <div class="col-3">
                <input type="number" min="0" max="100" class="select" name="take_or_pay_percentage" />
              </div>
            </div>
          </div>
          <div class="form-group mt-2 border-bottom">
            <div class="row">
              <div class="col-4">
                <p>Take or Pay Price:</p>
              </div>
              <div class="col-3">
                <input type="text" class="select" name="take_or_pay_price" />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Optional Delivery or Pay to the Seller:</p>
              </div>
              <div class="col-3">
                <select class="select" name="optional_delivery_to_seller" required>
                  <option value="YES">YES</option>
                  <option value="NO">NO</option>
                </select>
              </div>
            </div>
          </div>
          <span class="border-bottom"
            >In case the previous answer is NO:
          </span>
          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Delivery or Pay (0 to 100%):</p>
              </div>
              <div class="col-3">
                <input type="number" min="0" max="100" class="select" name="delivery_or_pay" />
              </div>
            </div>
          </div>
          <div class="form-group mt-2 border-bottom">
            <div class="row">
              <div class="col-4">
                <p>Delivery or Pay price:</p>
              </div>
              <div class="col-3">
                <input type="text" class="select" name="delivery_or_pay_price" />
              </div>
            </div>
          </div>
          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Payment term (5 to 180 days):</p>
              </div>
              <div class="col-3">
                <input type="number" class="select" name="payment_term" min="5" max="180" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Exchange Rate:</p>
              </div>
              <div class="col-3">
                <select class="select" name="exchange_rate" required>
                  <option value="BNA Ticket Seller">BNA Ticket Seller</option>
                  <option value="BNA Currency Seller">
                    BNA Currency Seller
                  </option>
                  <option value="ARS">ARS</option>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Default Rate Debts in USD:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select" name="default_rates_debts" required />
              </div>
            </div>
          </div>
          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Mortgage Rate Debts in Pesos:</p>
              </div>
              <div class="col-3">
                <input type="number" class="select" name="mortage_rate_debts" required />
              </div>
            </div>
          </div>

          <div class="form-group mt-2">
            <div class="row">
              <div class="col-4">
                <p>Auction Commission:</p>
              </div>
              <div class="col-3">
                <select class="select" name="auction_commision" required>
                  <option value="Paid by the Buyer">Paid by the Buyer</option>
                  <option value="Paid by the Seller">
                    Paid by the Seller
                  </option>
                  <option value="Paid by Both Parties">
                    Paid by Both Parties
                  </option>
                </select>
              </div>
            </div>
          </div>

          <div class="form-group mt-4">
            <div class="row">
              <div class="col-4">
                <p>Bid Maintenance Guarantee (Amount in ARS or USD):</p>
              </div>
              <div class="col-3">
                <input type="number" class="select" name="bid_maintain_gurantee" required />
              </div>
            </div>
          </div>




          
          <div class="flex items-center justify-end mt-4">
           

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'ml-4','type' => 'button','style' => 'background:rgb(18, 21, 179); colour:white','id' => 'submitButton']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-4','type' => 'button','style' => 'background:rgb(18, 21, 179); colour:white','id' => 'submitButton']); ?>
                <?php echo e(__('Add')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

          <!-- Group -->
        </div>
   

    </form>

</div>




</div>



<script>
document.getElementById("submitButton").addEventListener("click", function() {


  var inputs = document.getElementsByTagName("input");

  var filled = true;
  
  for (var i = 0; i < inputs.length; i++) {
    if (inputs[i].value == "") {
      filled = false;
      break;
    }
  }
  
  if (!filled) {
    alert("Please fill in all fields");
    return false;
  }



  const summer_1 = parseInt(elementFinder('summer_1').value);
  const summer_2 = parseInt(elementFinder('summer_2').value);
  const summer_3 = parseInt(elementFinder('summer_3').value);
  const summer_4 = parseInt(elementFinder('summer_4').value);
  const summer_5 = parseInt(elementFinder('summer_5').value);


  const sumOfTheSummer = summer_1 + summer_2 + summer_3 + summer_4 + summer_5;

  if (sumOfTheSummer == 100) {
    console.log("numberrs are equal to 100");
  }else {
    alert("value of Winter NQN, PTO, SCR,CHU and NOA are not equal to 100")
    return false 
  }


  const winter_1 = parseInt(elementFinder('winter_1').value);
  const winter_2 = parseInt(elementFinder('winter_2').value);
  const winter_3 = parseInt(elementFinder('winter_3').value);
  const winter_4 = parseInt(elementFinder('winter_4').value);
  const winter_5 = parseInt(elementFinder('winter_5').value);



  const sumOfTheWinter = winter_1 + winter_2 + winter_3 + winter_4 + winter_5;

  if (sumOfTheWinter == 100) {
    console.log("numberrs are equal to 100");
  }else {
    alert("value of Summer NQN, PTO, SCR,CHU and NOA are not equal to 100")
    return false 
  }



  elementFinder("natural_bid_add_form").submit();
 

});

function elementFinder(id) {
  return document.getElementById(id)
}





</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('buyer.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/buyer/add.blade.php ENDPATH**/ ?>