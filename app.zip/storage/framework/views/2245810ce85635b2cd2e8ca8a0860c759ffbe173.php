

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('components.additional.adminError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/buyer_main_css.css')); ?>" />
<script src="<?php echo e(asset('js/buyerConfig.js')); ?>" defer></script>


   
    <div class="card shadow mb-4">

        <div class="card-header py-3 bg-techbot-dark">
            <nav class="navbar">

                <div class="navbar-brand"><?php echo e($page_title); ?> </div>
              

            </nav>
        </div>
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="bg-techbot-dark">

                        <tr>

                            <th> #</th>
                            <th>Order Code</th>
                            <th>Buyer</th>
                            <th>Request Type</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tfoot class="bg-techbot-dark">
                        <tr>

                            <th> #</th>
                            <th>Order Code</th>
                            <th>Buyer</th>
                            <th>Request Type</th>
                            <th>Action</th>

                        </tr>

                    </tfoot>

                    <tbody>


                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="data-row">

                                <td><?php echo e($order->id); ?></td>

                                <td class="word-break"><?php echo e($order->code); ?> </td>
                                <td class="word-break"><?php echo e($order->user->social_name); ?> </td>
                                <td class="word-break"><?php echo e($order->purchase_request_for); ?> </td>
                                <td class="align-middle">

                                    <button title="Edit" type="button" data-toggle="modal" data-target="#modal_view<?php echo e($order->id); ?>" class="dataEditItemClass btn btn-success btn-sm"> view & Bids 
                                    
                                    </button>




                                    
                                    <button title="Edit" type="button" class="btn btn-info btn-sm">
                                        
                                        <a class="text-white" href="<?php echo e(route('superadmin_orders_edit', $order->id)); ?>">Edit</a>
                                         
                        
                                    </button>



                                    <button title="Edit" type="button" data-toggle="modal" data-target="#modal_status<?php echo e($order->id); ?>" class="btn btn-primary btn-sm"> Change status 
                                    
                                    </button>


                               
                                    <form method="POST" action="<?php echo e(route('superadmin_delete_order', $order->id)); ?>"
                                        id="delete-form-<?php echo e($order->id); ?>" style="display:none; ">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('delete')); ?>

                                    </form>



                                    <button title="Delete" class="dataDeleteItemClass btn btn-danger btn-sm" onclick="if(confirm('Are you sure Want To Delete ?')){
            document.getElementById('delete-form-<?php echo e($order->id); ?>').submit();
           }
           else{
            event.preventDefault();
           }
           " class="btn btn-danger btn-sm btn-raised">
                                        <i class="fa fa-trash" aria-hidden="false">

                                        </i>
                                    </button>



                                    



                                    <div class="modal fade" id="modal_status<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                              <h5 class="modal-title" id="exampleModalLabel">change status <?php echo e($order->supply_point_name); ?></h5>

                                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                              </button>
                                            </div>
                      
                                            <form action="<?php echo e(route('superadmin_update_order_status')); ?>" method="POST" >
                                              <?php echo csrf_field(); ?>
                                            
                                            <input type="text" name="order_hidden_id" id="" value="<?php echo e($order->id); ?>" required hidden>
                                         
                                            <div class="modal-body">
                                              
                      
                                              <div class="form-group mt-3">
                                                 <label for="status_change_select"> Status</label>
                                               
                                                    <select class="select form-control" name="status" required id="status_change_select">

                                                        <?php
                                                            $currentStatus = $order->status;
                                                        ?>
                      
                                                      <option value="open" <?php echo e($currentStatus == 'open' ? 'selected' : ''); ?>  >Open</option>
                                                      <option value="awarded" <?php echo e($currentStatus == 'awarded' ? 'selected' : ''); ?>  >Awarded</option>
                                                      <option value="under_analysis" <?php echo e($currentStatus == 'under_analysis' ? 'selected' : ''); ?>  >Under Analysis</option>
                                                      <option value="desert"  <?php echo e($currentStatus == 'desert' ? 'selected' : ''); ?>  >Desert</option>


                                                    </select>
                                              </div>
                                    
                      
                      
                                            </div>
                                            <div class="modal-footer">
                                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                              <button type="submit" class="btn btn-primary">Save changes</button>
                                            </div>
                      
                                          </form>
                                          </div>
                                        </div>
                                      </div>


                                    <?php
                                        $openOrder = $order;
                                        $bids = $order->bids;
                                    ?>


                                    <div class="modal fade" id="modal_view<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">

                                            <?php echo $__env->make('components.modal.bidcontent',[
                                                'openOrder' => $openOrder,
                                                'bids' => $bids
                                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                                          
                                        </div>
                                    </div>

                                    



                                 </td>


                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>


                </table>
            </div>
        </div>
    </div>





    <script>


        $(document).ready(function () {

            $('#dataTable').DataTable({
                dom: 'lBfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });

            
        });

    </script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>