

<?php $__env->startSection('content'); ?>





  <?php
        $authUser = Auth::user();
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">


            <!-- Begin Page Content -->
            <div class="container-fluid  p-1">

                <div class="row">

                    <!-- Growth Card Example -->

                    <div class="col-xl-3 col-md-6 mb-4 text-center topCard">
                        <div class="card border-left-primary shadow  py-4">
                            <div class="card-img-top ">
                            <i class="fas fa-bell fa-2x text-info"></i>
                            </div>
                            <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                <div class="h5 mb-0 font-weight-bold text-gray-800"> <a href="<?php echo e(route('superadmin_orders')); ?>"> All Purchase Requests   </a></div>
                                </div>

                            </div>
                            </div>
                        </div>
                 </div>



                   
                    <!-- Growth Card Example -->

                    <div class="col-xl-3 col-md-6 mb-4 text-center topCard">
                        <div class="card border-left-primary shadow  py-4">
                            <div class="card-img-top ">
                           <i class="fas fa-shopping-bag fa-2x text-info"></i>
                            </div>
                            <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                <div class="h5 mb-0 font-weight-bold text-gray-800">   <a href="<?php echo e(route('all_sellers')); ?>"> Registered Sellers   </a></div>
                                </div>

                            </div>
                            </div>
                        </div>
                 </div>


                    <!-- Growth Card Example -->

                    <div class="col-xl-3 col-md-6 mb-4 text-center topCard">
                        <div class="card border-left-primary shadow  py-4">
                            <div class="card-img-top ">
                            <i class="fas fa-table fa-2x text-info"></i>
                            </div>
                            <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                <div class="h5 mb-0 font-weight-bold text-gray-800">  <a href="<?php echo e(route('all_buyers')); ?>">  Registered Buyers   </a></div>
                                </div>

                            </div>
                            </div>
                        </div>
                 </div>



                </div>



            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>