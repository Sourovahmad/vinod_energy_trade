<a href="/">
    <img src="<?php echo e(asset('logo/logo.jpeg')); ?>" width="200" height="106" alt="logo" style="border-radius: 40%;">
  </a><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>