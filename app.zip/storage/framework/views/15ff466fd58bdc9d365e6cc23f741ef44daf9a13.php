<html lang="es">
    <head>
        <title>ARGOS ENERGIA</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap/main.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/buyer_main_css.css')); ?>" />
 
        <script src="<?php echo e(asset('js/buyerConfig.js')); ?>" defer></script>
    </head>
    <body>

        <div id="root">
             
         

         <?php echo $__env->make('components.additional.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           

            <?php echo $__env->yieldContent('content'); ?>

              
            <script src="<?php echo e(asset('js/bootstrapBundle.js')); ?>"></script>

    </body>

</html><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/layouts/app.blade.php ENDPATH**/ ?>