

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('components.additional.adminError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/buyer_main_css.css')); ?>" />
<script src="<?php echo e(asset('js/buyerConfig.js')); ?>" defer></script>


   
    <div class="card shadow mb-4">

        <div class="card-header py-3 bg-techbot-dark">
            <nav class="navbar">

                <div class="navbar-brand"> Bid Review  </div>
              

            </nav>
        </div>
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="bg-techbot-dark">

                        <tr>

                            <th> #</th>
                            <th>Order Code</th>
                            <th>Buyer</th>
                            <th>Seller</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tfoot class="bg-techbot-dark">
                        <tr>

                            <th> #</th>
                            <th>Order Code</th>
                            <th>Buyer</th>
                            <th>Seller</th>
                            <th>Action</th>

                        </tr>

                    </tfoot>

                    <tbody>


                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="data-row">

                                <td><?php echo e($order->id); ?></td>

                                <td class="word-break"><?php echo e($order->order->code); ?> </td>
                                <td class="word-break"><?php echo e($order->order->user->social_name); ?> </td>
                                <td class="word-break"><?php echo e($order->user->social_name); ?> </td>
                               
                                <td class="align-middle">

                                    <button title="Edit" type="button" data-toggle="modal" data-target="#modal_view<?php echo e($order->id); ?>" class="dataEditItemClass btn btn-success btn-sm"> <i class="fas fa-eye"></i> </button>



                                    


                                    <?php
                                        $openOrder = $order->order;
                                        $currentBid = $order;
                                    ?>



                                    <div class="modal fade" id="modal_view<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">

                                            <?php echo $__env->make('components.modal.bidcontent',[
                                                'openOrder' => $openOrder,
                                                'currentBid' => $currentBid
                                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                                          
                                        </div>
                                      </div>





                                    

                                 </td>


                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>


                </table>
            </div>
        </div>
    </div>





    <script>


        $(document).ready(function () {

            $('#dataTable').DataTable({
                dom: 'lBfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });

            
        });

    </script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\laravel\vinod_energy_trade\resources\views/admin/review/index.blade.php ENDPATH**/ ?>