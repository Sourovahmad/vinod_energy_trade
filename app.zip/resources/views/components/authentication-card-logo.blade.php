<a href="/">
    <img src="{{ asset('logo/logo.jpeg') }}" width="200" height="106" alt="logo" style="border-radius: 40%;">
  </a>