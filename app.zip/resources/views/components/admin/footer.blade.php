  <!-- Footer -->
  <footer class="sticky-footer bg-light">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; {{ config('app.name', 'Laravel') }} - {{now()->format("Y")}}</span>
      </div>
    </div>
   </footer>
  <!-- End of Footer -->